"""
__init__ file for Appwrite Sites integration package
"""

from .sites_manager import AppwriteSitesManager

__all__ = ['AppwriteSitesManager']