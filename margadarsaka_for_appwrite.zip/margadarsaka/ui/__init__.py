"""
UI components for Margadarsaka application.
"""

__version__ = "0.1.0"
