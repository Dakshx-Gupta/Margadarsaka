"""
Custom Components for Margadarsaka
This module exports all custom Streamlit components
"""

from .rating_component import rating_component

__all__ = ["rating_component"]