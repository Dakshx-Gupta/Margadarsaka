"""Margadarsaka - Intelligent Career Advisor"""

__version__ = "0.1.0"
